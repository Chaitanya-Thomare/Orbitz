export const paletone = {
    backg : '#333345',
    backd : '#23232f',
    hlit3: '#725A7A',
    hlit2: '#bd6868',
    hlit1: '#ff7c75'
}